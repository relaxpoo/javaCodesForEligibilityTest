package com.project1_frontend.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


public class Customer implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	
	private int CustomerId;
	private String CustomerName;
	private String CustomerEmail;
	private String CustomerPassword;
	private String CustomerUserName;
	private boolean enable;

		
		public String getCustomerName() {
			return CustomerName;
		}
		public void setCustomerName(String customerName) {
			CustomerName = customerName;
		}
		public String getCustomerEmail() {
			return CustomerEmail;
		}
		public void setCustomerEmail(String customerEmail) {
			CustomerEmail = customerEmail;
		}
		public String getCustomerPassword() {
			return CustomerPassword;
		}
		public void setCustomerPassword(String customerPassword) {
			CustomerPassword = customerPassword;
		}
		public String getCustomerUserName() {
			return CustomerUserName;
		}
		public void setCustomerUserName(String customerUserName) {
			CustomerUserName = customerUserName;
		}
		public boolean isEnable() {
			return enable;
		}
		public void setEnable(boolean enable) {
			this.enable = enable;
		}
		
}
