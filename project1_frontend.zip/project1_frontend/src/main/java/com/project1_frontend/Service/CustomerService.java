package com.project1_frontend.Service;

import com.project1_frontend.model.Customer;

public interface CustomerService
{
	void addcustomer(Customer customer);
}
