package com.project1_frontend.Service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project1_frontend.Dao.CustomerDao;
import com.project1_frontend.Service.CustomerService;
import com.project1_frontend.model.Customer;


public class CustomerServiceImpl implements CustomerService
{
	
	CustomerDao customerdao;
	
	public void addcustomer(Customer customer)
	{
	
		customerdao.addcustomer(customer);
	}

}
