package com.project1_frontend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.project1_frontend.Service.CustomerService;
import com.project1_frontend.model.Customer;

@Controller
public class project1_frontendcontroller {
	
	
	
	@RequestMapping("/")
	public String home(Model model)
	{
		model.addAttribute("message","Hello I am alive.");
		return "home";
			
	}
	@RequestMapping("/aboutus")
	public String aboutUs()
	{
		return "aboutUs";
	}
	@RequestMapping("/productlist")
	public String productlist(Model model)
	{
		return "Product";
	}
	
	@RequestMapping("/SignUp")
	public String register(Model model)
	{
		return "SignUp";
	}
	
}
