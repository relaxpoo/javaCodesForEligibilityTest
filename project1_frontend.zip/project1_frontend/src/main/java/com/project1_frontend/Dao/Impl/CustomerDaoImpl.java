package com.project1_frontend.Dao.Impl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.project1_frontend.Dao.CustomerDao;
import com.project1_frontend.model.Customer;

public class CustomerDaoImpl implements CustomerDao
{
	
	SessionFactory sessionfactory;
	
	public void addcustomer(Customer customer)
	{
		Session session = sessionfactory.getCurrentSession();
		session.saveOrUpdate(customer);

	}

}
