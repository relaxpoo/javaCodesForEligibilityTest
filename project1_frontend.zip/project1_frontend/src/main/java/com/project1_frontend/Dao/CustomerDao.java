package com.project1_frontend.Dao;

import com.project1_frontend.model.Customer;

public interface CustomerDao
{
	void addcustomer(Customer customer);
}
